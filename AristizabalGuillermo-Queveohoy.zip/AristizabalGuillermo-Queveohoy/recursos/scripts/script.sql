CREATE DATABASE queveohoy; 

USE queveohoy;

CREATE TABLE pelicula (
    id Int Not Null auto_increment,
    titulo varchar(100) Not Null,
    duracion int(5),
    director varchar(400),
    anio int (5),
    fecha_lanzamiento date,
    puntuacion int (2),
    poster varchar(300),
    trama varchar(700),
    genero_id int(5),
     PRIMARY KEY (id)    
  
    
    );


CREATE TABLE genero (
    id Int Not Null auto_increment,
    nombre varchar(30) Not Null,
    PRIMARY KEY (id)
    );
    
CREATE TABLE actor (
    id Int Not Null auto_increment,
    nombre varchar(30) Not Null,
    PRIMARY KEY (id)
    );

    CREATE TABLE actor_pelicula (
    id Int Not Null auto_increment,
    actor_id int (5),
    pelicula_id int (5),
    PRIMARY KEY (id),
    FOREIGN KEY (actor_id) REFERENCES actor(id),
    FOREIGN KEY (pelicula_id) REFERENCES pelicula(id)
    );
    
    ALTER TABLE pelicula add FOREIGN KEY (genero_id) references genero(id); -- lo modifique por que me estaba poniendo problema, seguro era porque no estaba creada aun la tabla genero.